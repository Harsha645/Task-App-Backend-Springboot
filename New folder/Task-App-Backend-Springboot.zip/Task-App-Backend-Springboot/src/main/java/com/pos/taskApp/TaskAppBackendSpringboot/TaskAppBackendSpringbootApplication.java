package com.pos.taskApp.TaskAppBackendSpringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskAppBackendSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskAppBackendSpringbootApplication.class, args);
	}

}
